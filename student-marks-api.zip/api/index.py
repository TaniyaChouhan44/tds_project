import json

with open("data.json", "r") as f:
    student_data = json.load(f)
    marks_map = {entry["name"]: entry["marks"] for entry in student_data}

def handler(request, response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET"

    if request.method == "OPTIONS":
        return response.status(200).send("")

    names = request.query.getlist("name")
    result = [marks_map.get(name, None) for name in names]
    return response.json({ "marks": result })
